import React from 'react';

const CheckOut = () => {
  return (
    <div>
      <h2>Checkout</h2>
    </div>
  );
};

export default CheckOut;